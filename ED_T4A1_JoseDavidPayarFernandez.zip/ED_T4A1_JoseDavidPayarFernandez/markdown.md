## Indice de contenidos
- [Encabezados](#encabezado-nivel-1)  
- [Cambios tipograficos](#cambios-tipograficos)  
- [Listas](#listas)  
- [Códigos](#código)  
- [Citas](#citas)  
- [Enlaces](#enlaces) 
- [Imagenes](#imagenes)  
- [Tablas](#tablas)
- [Lineas Horizontales](#lineas-horizontales)


# Encabezado nivel 1
## Encabezado nivel 2
### Encabezado nivel 3
#### Encabezado nivel 4


## Cambios tipograficos

Texto en *cursiva*  
Texto en **negrita**  
Texto en **negrita y *cursiva***  
Texto ~~tachado~~  
Texto ==remarcado==



## Listas
### Listas sin orden

- Elemento 1
    - Subelemento 1.1
    - Subelemento 1.2
- Elemento 2
- Elemento 3

### Listas ordenadas

1. Paso uno
    1. Subpaso 1
    2. Subpaso 2
2. Paso dos
3. Paso tres



## Código

### Código en línea

Usa `print()` para mostrar texto


## Citas

> Esto es una cita



## Enlaces

### Enlaces a paginas o elementos externos

Esto es un enlace hacia *[Youtube](https://www.youtube.com/?app=desktop&hl=es)*

### Enlaces a otros elementos del mismo documento

[Enlace a elemento del documento](#indice-de-contenidos)



## Imagenes

### Imagenes externas

![carafeliz](/ED_T4A1_JoseDavidPayarFernandez/fotos/happy-smiley-pink-cheeks-cartoon-260nw-613884710.webp)
![carafeliz2](https://png.pngtree.com/png-vector/20210123/ourmid/pngtree-3d-emoji-character-happy-face-png-image_2796353.jpg)



## Tablas

|Pais|Capital|Moneda|
|:---|:---:|---:|   
|España|Madrid|Euro|
|Francia|Paris|Euro|
|Rusia|Moscú|Rublos|



## Lineas horizontales

Una linea...

---

...despues de la línea



## Saltos de linea

Un salto de linea se hace  
añadiendo dos espacion despues de la palabra.


## Lista de tareas

Como es "Hola" en **Inglés**
- [X] Hello
- [ ] Bonjour
- [ ] Hallo


## Emojis
Me parto de risa :joy::joy::joy:


## Formulas matematicas

Formula de una ecuacion: $f(x) = \frac{x}{2}$


## Referencias

> Este es un texto citado. Se usa el símbolo de mayor que (>) al inicio de la línea [1, 2, 7].

## Referencias al pie[^1]

[^1]: Esto es una referencia al pie.









